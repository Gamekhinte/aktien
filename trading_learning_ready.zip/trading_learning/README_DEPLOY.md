# Trading-App: GitHub + Streamlit + Supabase

## Dateien
- `app.py` = integrierte Streamlit-App mit gemeinsamem persistentem ML-Lernen
- `requirements.txt` = benötigte Python-Pakete
- `supabase_learning.sql` = DB-Migration für das Lernsystem
- `.streamlit_secrets.example.toml` = Beispiel für Secrets, ohne echte Schlüssel

## Wichtig
Die App bleibt Paper-Trading/Analyse. Es werden keine echten Orders aus dem Lernsystem platziert.

## GitHub
Lade `app.py` und `requirements.txt` in dein Repository hoch. Optional kannst du die SQL-Datei mit hochladen.

## Supabase
Die Lern-Tabellen wurden im verbundenen Supabase-Projekt bereits angelegt. `supabase_learning.sql` dient als reproduzierbare Migration.

## Streamlit Secrets
Für Streamlit Community Cloud unter App -> Settings -> Secrets eintragen:

```toml
SUPABASE_URL = "https://DEIN-PROJEKT.supabase.co"
SUPABASE_SERVICE_ROLE_KEY = "DEIN-SERVICE-ROLE-KEY"
```

Den Service-Role-Key niemals in GitHub, `app.py` oder `requirements.txt` schreiben.

## Lernlogik
Beim Klick auf "Daten sammeln & gemeinsames Modell trainieren" werden historische Paper-Daten in `learning_examples` synchronisiert. Ab 200 gemeinsamen Beispielen wird ein Walk-Forward-Modell trainiert. Das neue Modell wird nur als aktiv markiert, wenn seine Validierungs-Trefferquote mindestens der des bisher aktiven Modells entspricht. Abgelehnte Modelle bleiben als Historie gespeichert.

## Automatisches Lernen
Streamlit Community Cloud ist kein dauerhafter Background-Worker. Das Training wird deshalb ausgelöst, wenn die App benutzt wird. Für echtes zeitgesteuertes Training ohne Nutzerbesuch braucht das Projekt später einen separaten Worker/Cron-Dienst.
